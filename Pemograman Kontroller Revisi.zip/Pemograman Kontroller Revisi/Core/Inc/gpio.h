#ifndef GPIO_H
#define GPIO_H

#include "stm32f4xx_hal.h"

void MX_GPIO_Init(void);

#endif
