#ifndef USART_H
#define USART_H

#include "stm32f4xx_hal.h"

extern UART_HandleTypeDef huart2;

void MX_USART2_UART_Init(void);

#endif
